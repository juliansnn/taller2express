const express = require('express');
const router = express.Router();

router.get('/', (req, res) =>{
    res.render('index', {
        title: 'Inicio'
    });
});
router.get('/new-entry', (req, res) =>{
    res.render('new-entry', {
        title: 'Nueva Entrada'
    });
});
module.exports=router;